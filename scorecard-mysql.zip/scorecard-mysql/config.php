<?php
// Scorecard — database + site configuration.
// Fill these in once the MySQL database + user exist in cPanel (Databases → MySQL
// Databases). cPanel prefixes both the database name and the username with your
// cPanel account username followed by an underscore (e.g. ingeni12_scorecard) —
// use the full prefixed names here, not just what you typed when creating them.

define('DB_HOST', 'localhost');
define('DB_NAME', 'ingeni12_scorecard');   // <-- replace with your real DB name
define('DB_USER', 'ingeni12_scorecard');   // <-- replace with your real DB username
define('DB_PASS', '*@$_BelleSoh729!');           // <-- replace with that user's password

// Where uploaded files (task attachments, check-in photos, letters of proof) are
// stored on disk. This MUST be outside the web-accessible document root — one level
// above public_html's scorecard-mysql folder — so nobody can download a file by
// guessing/guessing its URL; every download instead goes through a signed-link PHP
// script that checks permissions first. __DIR__ here is the folder this file lives
// in (api/ and index.html's folder), so '../../scorecard-storage' lands it next to
// public_html, not inside it.
define('STORAGE_ROOT', __DIR__ . '/../../scorecard-storage');

// A long random secret used to sign file-download links (so a link can't be forged)
// and session tokens. Generate your own — e.g. run this once on your computer or in
// cPanel's Terminal and paste the output here:
//   php -r "echo bin2hex(random_bytes(32));"
define('APP_SECRET', '8f2a91c7e3b5d04619fa2c8e7d53b196a04f71cde83b2a95106f4c7e82d913a');

// How long a login session lasts before the browser needs to sign in again.
define('SESSION_LIFETIME_DAYS', 30);

// Sender address for forgot-password emails. Needs a working mailbox on this cPanel
// account (Email Accounts → create one, e.g. noreply@ingenious.sg) for deliverability —
// see lib/mail.php for how this is used.
define('MAIL_FROM_ADDRESS', 'noreply@ingenious.sg');
define('MAIL_FROM_NAME', 'Scorecard');

// Geocoding (reverse-geocode check-in coordinates into an address) — same OpenCage
// setup as the Supabase Edge Function this replaces. Leave blank to fall back to
// Nominatim (free, no key, slightly less reliable) — see api/reverse-geocode.php.
define('OPENCAGE_API_KEY', 'e91d1a8b4ec944328cf7256f6abbae77');

error_reporting(E_ALL);
ini_set('display_errors', '0'); // never leak PHP errors to the browser in production
ini_set('log_errors', '1');
