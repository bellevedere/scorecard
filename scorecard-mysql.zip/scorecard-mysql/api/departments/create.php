<?php
// POST { name, colorHex, companyId } -> { department }. CEO/admin only. Replaces
// addDepartment().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$name = trim((string)($body['name'] ?? ''));
$colorHex = $body['colorHex'] ?? null;
$companyId = (string)($body['companyId'] ?? '');
if ($name === '' || $companyId === '') json_error('Missing name or companyId.', 400);

$id = new_uuid();
db()->prepare('INSERT INTO departments (id, company_id, name, color_hex, active) VALUES (?, ?, ?, ?, 1)')
  ->execute([$id, $companyId, $name, $colorHex]);

json_out(['department' => ['id' => $id, 'name' => $name, 'colorHex' => $colorHex, 'companyId' => $companyId, 'active' => true]]);
