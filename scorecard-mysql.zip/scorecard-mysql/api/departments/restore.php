<?php
// POST { deptId } -> { ok: true }. CEO/admin only. Replaces restoreDepartment().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$deptId = (string)($body['deptId'] ?? '');
if ($deptId === '') json_error('Missing deptId.', 400);

db()->prepare('UPDATE departments SET active = 1 WHERE id = ?')->execute([$deptId]);
json_out(['ok' => true]);
