<?php
// POST { taskId } -> { ok: true }. CEO/admin only. Replaces removeTaskFromGoal(). Note:
// task_id on goal_records is deliberately NOT a foreign key (see schema.sql), so any
// existing frozen records for this task survive the delete untouched, same as Postgres did.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$taskId = (string)($body['taskId'] ?? '');
if ($taskId === '') json_error('Missing taskId.', 400);

db()->prepare('DELETE FROM goal_tasks WHERE id = ?')->execute([$taskId]);
json_out(['ok' => true]);
