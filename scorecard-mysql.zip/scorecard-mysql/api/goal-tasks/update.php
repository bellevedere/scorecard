<?php
// POST { taskId, weight?, text?, requiresAttachment?, requiresRemark? } -> { ok: true }.
// CEO/admin only. Combines updateTaskWeight()/updateTaskRequiresAttachment()/
// updateTaskRequiresRemark()/updateTaskText() into one endpoint — pass only the field(s)
// you're changing. A weight change notifies already-assigned staff (unless the goal is
// locked), matching updateTaskWeight()'s original behavior; the other fields are silent,
// same as the original.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php';
require_once __DIR__ . '/../../lib/goal_records.php';
require_once __DIR__ . '/../../lib/notifications.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$taskId = (string)($body['taskId'] ?? '');
if ($taskId === '') json_error('Missing taskId.', 400);

$stmt = db()->prepare('SELECT * FROM goal_tasks WHERE id = ?');
$stmt->execute([$taskId]);
$task = $stmt->fetch();
if (!$task) json_error('Task not found.', 404);

$sets = [];
$params = [];
$weightChanged = false;
if (array_key_exists('weight', $body)) { $sets[] = 'weight = ?'; $params[] = $body['weight']; $weightChanged = true; }
if (array_key_exists('text', $body)) { $sets[] = 'text = ?'; $params[] = $body['text']; }
if (array_key_exists('requiresAttachment', $body)) { $sets[] = 'requires_attachment = ?'; $params[] = !empty($body['requiresAttachment']) ? 1 : 0; }
if (array_key_exists('requiresRemark', $body)) { $sets[] = 'requires_remark = ?'; $params[] = !empty($body['requiresRemark']) ? 1 : 0; }
if (!$sets) json_out(['ok' => true]);

$params[] = $taskId;
db()->prepare('UPDATE goal_tasks SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);

if ($weightChanged) {
  $goal = find_goal($task['goal_id']);
  if ($goal && !is_goal_locked($goal)) {
    foreach (goal_assigned_employee_ids($task['goal_id']) as $empId) {
      notify_employee($empId, "Points changed for \"{$task['text']}\" in \"{$goal['name']}\" (now {$body['weight']} pts)", true);
    }
  }
}

json_out(['ok' => true]);
