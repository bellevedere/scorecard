<?php
// POST { goalId, text, weight, requiresAttachment, requiresRemark } -> { task }. CEO/admin
// only. Replaces addTaskToGoal() — appends one task to a goal's live task list, notifying
// already-assigned staff unless the goal is locked.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php';
require_once __DIR__ . '/../../lib/goal_records.php';
require_once __DIR__ . '/../../lib/notifications.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$goalId = (string)($body['goalId'] ?? '');
$text = trim((string)($body['text'] ?? ''));
$weight = (float)($body['weight'] ?? 0);
$requiresAttachment = !empty($body['requiresAttachment']);
$requiresRemark = !empty($body['requiresRemark']);
if ($goalId === '' || $text === '') json_error('Missing goalId or text.', 400);

$goal = find_goal($goalId);
if (!$goal) json_error('Goal not found.', 404);

$existingCount = count(goal_tasks_for($goalId));
$taskId = new_uuid();
db()->prepare(
  'INSERT INTO goal_tasks (id, goal_id, text, weight, requires_attachment, requires_remark, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)'
)->execute([$taskId, $goalId, $text, $weight, $requiresAttachment ? 1 : 0, $requiresRemark ? 1 : 0, $existingCount]);

if (!is_goal_locked($goal)) {
  foreach (goal_assigned_employee_ids($goalId) as $empId) {
    notify_employee($empId, "New task added to \"{$goal['name']}\": {$text}", true);
  }
}

json_out(['task' => ['id' => $taskId, 'text' => $text, 'weight' => $weight, 'requiresAttachment' => $requiresAttachment, 'requiresRemark' => $requiresRemark]]);
