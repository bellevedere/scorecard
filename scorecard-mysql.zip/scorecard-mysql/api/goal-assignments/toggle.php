<?php
// POST { goalId, employeeId } -> { assigned: bool }. CEO/admin only. Replaces
// toggleAssignment() — assigns if not currently assigned, unassigns if it is.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$goalId = (string)($body['goalId'] ?? '');
$employeeId = (string)($body['employeeId'] ?? '');
if ($goalId === '' || $employeeId === '') json_error('Missing goalId or employeeId.', 400);

$stmt = db()->prepare('SELECT 1 FROM goal_assignments WHERE goal_id = ? AND employee_id = ?');
$stmt->execute([$goalId, $employeeId]);
$has = (bool)$stmt->fetch();

if ($has) {
  db()->prepare('DELETE FROM goal_assignments WHERE goal_id = ? AND employee_id = ?')->execute([$goalId, $employeeId]);
} else {
  db()->prepare('INSERT INTO goal_assignments (goal_id, employee_id) VALUES (?, ?)')->execute([$goalId, $employeeId]);
}

json_out(['assigned' => !$has]);
