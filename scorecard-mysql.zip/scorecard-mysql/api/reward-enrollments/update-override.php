<?php
// POST { schemeId, employeeId, updateAmount, remark } -> { ok: true }. CEO/admin only.
// Replaces updateRewardEmployeeOverride() — editing an override implicitly enrolls the
// employee too (row-presence rule), since the admin UI lets you type an amount before
// ticking the enrollment checkbox.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$schemeId = (string)($body['schemeId'] ?? '');
$employeeId = (string)($body['employeeId'] ?? '');
$updateAmount = (float)($body['updateAmount'] ?? 0);
$remark = (string)($body['remark'] ?? '');
if ($schemeId === '' || $employeeId === '') json_error('Missing schemeId or employeeId.', 400);

db()->prepare(
  'INSERT INTO reward_enrollments (scheme_id, employee_id, update_amount, remark) VALUES (?, ?, ?, ?)
   ON DUPLICATE KEY UPDATE update_amount = VALUES(update_amount), remark = VALUES(remark)'
)->execute([$schemeId, $employeeId, $updateAmount, $remark]);

json_out(['ok' => true]);
