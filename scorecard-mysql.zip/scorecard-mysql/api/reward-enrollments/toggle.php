<?php
// POST { schemeId, employeeId } -> { enrolled: bool }. CEO/admin only. Replaces
// toggleRewardEnrollment() — reward_enrollments has no separate "enrolled" flag; a row's
// mere presence for (scheme_id, employee_id) IS the enrollment. Enrolling seeds the row
// with the scheme's current base_amount; un-enrolling deletes the row outright.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$schemeId = (string)($body['schemeId'] ?? '');
$employeeId = (string)($body['employeeId'] ?? '');
if ($schemeId === '' || $employeeId === '') json_error('Missing schemeId or employeeId.', 400);

$stmt = db()->prepare('SELECT base_amount FROM reward_schemes WHERE id = ?');
$stmt->execute([$schemeId]);
$scheme = $stmt->fetch();
if (!$scheme) json_error('Reward scheme not found.', 404);

$stmt = db()->prepare('SELECT 1 FROM reward_enrollments WHERE scheme_id = ? AND employee_id = ?');
$stmt->execute([$schemeId, $employeeId]);
$has = (bool)$stmt->fetch();

if ($has) {
  db()->prepare('DELETE FROM reward_enrollments WHERE scheme_id = ? AND employee_id = ?')->execute([$schemeId, $employeeId]);
} else {
  db()->prepare('INSERT INTO reward_enrollments (scheme_id, employee_id, update_amount, remark) VALUES (?, ?, ?, ?)')
    ->execute([$schemeId, $employeeId, $scheme['base_amount'], '']);
}

json_out(['enrolled' => !$has]);
