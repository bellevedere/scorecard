<?php
// GET -> every table the app needs right after login, in one response. Replaces the
// Promise.all([...]) of 12 separate supabaseClient.from(...).select("*") calls index.html
// makes on load. Returns the SAME raw column shape those calls did (snake_case, straight
// from the DB) — index.html's own mapping code (setCompanies/setGoals/etc.) already turns
// this into its camelCase local state, so that mapping code does not need to change.
//
// Both roles get the same full tables here for now (ceo is a global superadmin with no
// company scoping in the original RLS model either — see claude/scorecard-rls-status.md —
// and nothing in the old staff RLS actually narrowed these particular SELECTs beyond what
// the frontend already filters for display, e.g. employeeGoals()/assignedEmployeeIds).

require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/json_helpers.php';

require_method('GET');
require_session();

$pdo = db();

$companies = cast_bools($pdo->query('SELECT * FROM companies')->fetchAll(), ['active']);
$departments = cast_bools($pdo->query('SELECT * FROM departments')->fetchAll(), ['active']);
$employees = cast_bools($pdo->query('SELECT * FROM employees')->fetchAll(), ['active']);
foreach ($employees as &$e) { unset($e['password_hash']); } // never leak hashes to the browser
unset($e);

$goals = cast_numbers(
  cast_bools($pdo->query('SELECT * FROM goals')->fetchAll(), ['is_team_goal', 'auto_assign_whole_dept', 'is_annual', 'active']),
  []
);

$goalTasks = cast_numbers(
  cast_bools($pdo->query('SELECT * FROM goal_tasks ORDER BY sort_order ASC')->fetchAll(), ['requires_attachment', 'requires_remark']),
  ['weight']
);

$goalAssignments = $pdo->query('SELECT * FROM goal_assignments')->fetchAll();

$goalRecords = cast_numbers(
  cast_bools($pdo->query('SELECT * FROM goal_records')->fetchAll(), ['done', 'no_attachment_reason']),
  ['awarded_points', 'awarded_weight']
);

$goalMonthHistory = decode_json_fields(
  $pdo->query('SELECT * FROM goal_month_history')->fetchAll(),
  ['tasks_snapshot', 'assigned_snapshot', 'records_snapshot']
);

$goalFutureVersions = decode_json_fields(
  $pdo->query('SELECT * FROM goal_future_versions')->fetchAll(),
  ['tasks_snapshot', 'assigned_snapshot']
);

$checkIns = cast_numbers(
  cast_bools($pdo->query('SELECT * FROM check_ins ORDER BY timestamp DESC')->fetchAll(), ['within_window']),
  ['lat', 'lng', 'elapsed_sec']
);

$rewardSchemes = cast_numbers(
  cast_bools($pdo->query('SELECT * FROM reward_schemes')->fetchAll(), ['active']),
  ['base_amount', 'future_base_amount']
);

$rewardEnrollments = cast_numbers($pdo->query('SELECT * FROM reward_enrollments')->fetchAll(), ['update_amount']);

json_out([
  'companies' => $companies,
  'departments' => $departments,
  'employees' => $employees,
  'goals' => $goals,
  'goal_tasks' => $goalTasks,
  'goal_assignments' => $goalAssignments,
  'goal_records' => $goalRecords,
  'goal_month_history' => $goalMonthHistory,
  'goal_future_versions' => $goalFutureVersions,
  'check_ins' => $checkIns,
  'reward_schemes' => $rewardSchemes,
  'reward_enrollments' => $rewardEnrollments,
]);
