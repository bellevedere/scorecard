<?php
// GET ?path=<relative path stored in attachment_url/photo_url/archived_proof_url> -> streams
// the file. Replaces Supabase Storage's createSignedUrl() + the signed download it produced.
// Permission: CEO can view anything; a staff member can only view a file stored under their
// own employee id (folder convention: {companyId}/{employeeId}/...), matching the old
// storage RLS policy (`storage.foldername(name)[2] = auth.uid()`).
//
// NOTE: this is a same-origin, cookie-authenticated download (not yet a separately signed,
// time-limited link like the Supabase version used) — sufficient since it's only ever linked
// to from inside the already-logged-in app, but worth tightening later if these links are
// ever shared outside the app itself.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/storage.php';

require_method('GET');
$me = require_session();

$relPath = (string)($_GET['path'] ?? '');
if ($relPath === '') json_error('Missing path.', 400);

$owner = storage_owner_employee_id($relPath);
if ($me['role'] !== 'ceo' && $owner !== $me['id']) json_error('Not allowed.', 403);

$absPath = storage_abs_path($relPath);
if (!$absPath || !is_file($absPath)) json_error('File not found.', 404);

$mime = function_exists('mime_content_type') ? (mime_content_type($absPath) ?: 'application/octet-stream') : 'application/octet-stream';
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($absPath));
header('Content-Disposition: inline; filename="' . basename($absPath) . '"');
header('Cache-Control: private, max-age=0, no-cache');
readfile($absPath);
exit;
