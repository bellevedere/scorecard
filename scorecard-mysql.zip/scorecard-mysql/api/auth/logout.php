<?php
// POST -> { ok: true }. Replaces supabaseClient.auth.signOut().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
destroy_session();
json_out(['ok' => true]);
