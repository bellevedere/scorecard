<?php
// POST { newPassword } -> { ok: true }. Must be signed in. Replaces the plain
// supabaseClient.auth.updateUser({ password }) calls used when someone changes
// their own password from inside the app (not the forgot-password flow — that's
// forgot-password-reset.php).

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
$emp = require_session();
$body = read_json_body();
$newPassword = (string)($body['newPassword'] ?? '');

if (strlen($newPassword) < 6) {
  json_error('Password must be at least 6 characters.', 400);
}

db()->prepare('UPDATE employees SET password_hash = ? WHERE id = ?')
  ->execute([hash_password($newPassword), $emp['id']]);

json_out(['ok' => true]);
