<?php
// GET -> the signed-in employee's session payload, or 401 if not signed in.
// Called once on page load to restore a session after a refresh — replaces
// supabaseClient.auth.getSession() + the employees select-by-id that followed it.

require_once __DIR__ . '/../../lib/auth.php';

require_method('GET');
$emp = require_session();
json_out(session_payload($emp));
