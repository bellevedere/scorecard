<?php
// POST { email } -> { ok: true } (always, whether or not that email exists — never
// reveal which). Emails a 6-digit code, valid for 15 minutes. Replaces
// supabaseClient.auth.resetPasswordForEmail().

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/mail.php';

require_method('POST');
$body = read_json_body();
$email = trim(strtolower($body['email'] ?? ''));
if ($email === '') json_error('Email is required.', 400);

$stmt = db()->prepare('SELECT id, name FROM employees WHERE email = ? AND active = 1');
$stmt->execute([$email]);
$emp = $stmt->fetch();

if ($emp) {
  $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
  $expiresAt = (new DateTime())->modify('+15 minutes')->format('Y-m-d H:i:s');

  db()->prepare('INSERT INTO password_resets (id, employee_id, code_hash, expires_at) VALUES (?, ?, ?, ?)')
    ->execute([new_uuid(), $emp['id'], password_hash($code, PASSWORD_BCRYPT), $expiresAt]);

  send_mail(
    $email,
    'Your Scorecard password reset code',
    "Hi {$emp['name']},\n\nYour password reset code is: $code\n\nThis code expires in 15 minutes. If you didn't request this, you can ignore this email.\n"
  );
}

// Same response either way — don't let this endpoint be used to check which emails exist.
json_out(['ok' => true]);
