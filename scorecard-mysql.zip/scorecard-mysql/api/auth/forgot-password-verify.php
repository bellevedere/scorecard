<?php
// POST { email, code } -> { resetToken } on success. Replaces
// supabaseClient.auth.verifyOtp({ type: "recovery" }).
// The returned resetToken (the password_resets row's own id — a random UUID never
// exposed before this point) is what forgot-password-reset.php requires next,
// alongside the new password — it stands in for the temporary "recovery session"
// Supabase's verifyOtp used to create.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
$body = read_json_body();
$email = trim(strtolower($body['email'] ?? ''));
$code = trim((string)($body['code'] ?? ''));
if ($email === '' || $code === '') json_error('Email and code are required.', 400);

$stmt = db()->prepare(
  'SELECT pr.* FROM password_resets pr JOIN employees e ON e.id = pr.employee_id
   WHERE e.email = ? AND pr.used = 0 AND pr.expires_at > NOW()
   ORDER BY pr.created_at DESC LIMIT 5'
);
$stmt->execute([$email]);
$candidates = $stmt->fetchAll();

$match = null;
foreach ($candidates as $row) {
  if (password_verify($code, $row['code_hash'])) { $match = $row; break; }
}
if (!$match) json_error('That code is invalid or has expired.', 400);

db()->prepare('UPDATE password_resets SET verified_at = NOW() WHERE id = ?')->execute([$match['id']]);

json_out(['resetToken' => $match['id']]);
