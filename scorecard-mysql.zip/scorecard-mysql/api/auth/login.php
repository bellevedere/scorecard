<?php
// POST { email, password } -> { role, employeeId, name, email, deptId, companyId }
// Replaces supabaseClient.auth.signInWithPassword() + the employees lookup that
// followed it in signInAndEnter().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
$body = read_json_body();
$email = trim(strtolower($body['email'] ?? ''));
$password = (string)($body['password'] ?? '');

if ($email === '' || $password === '') {
  json_error('Email and password are required.', 400);
}

$stmt = db()->prepare('SELECT * FROM employees WHERE email = ? AND active = 1');
$stmt->execute([$email]);
$emp = $stmt->fetch();

// Same generic message whether the email doesn't exist or the password is wrong —
// never reveal which one it was, same as before.
if (!$emp || !verify_password($password, $emp['password_hash'])) {
  json_error('Invalid email or password.', 401);
}

create_session($emp['id']);
json_out(session_payload($emp));
