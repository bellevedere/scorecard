<?php
// POST { resetToken, newPassword } -> { ok: true }. Replaces the updateUser({password})
// call that finished off the old forgot-password flow.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
$body = read_json_body();
$resetToken = (string)($body['resetToken'] ?? '');
$newPassword = (string)($body['newPassword'] ?? '');
if ($resetToken === '' || $newPassword === '') json_error('Missing reset token or new password.', 400);
if (strlen($newPassword) < 6) json_error('Password must be at least 6 characters.', 400);

$stmt = db()->prepare(
  "SELECT * FROM password_resets
   WHERE id = ? AND used = 0 AND verified_at IS NOT NULL AND expires_at > NOW()"
);
$stmt->execute([$resetToken]);
$reset = $stmt->fetch();
if (!$reset) json_error('This reset link has expired — please request a new code.', 400);

$pdo = db();
$pdo->beginTransaction();
try {
  $pdo->prepare('UPDATE employees SET password_hash = ? WHERE id = ?')
    ->execute([hash_password($newPassword), $reset['employee_id']]);
  $pdo->prepare('UPDATE password_resets SET used = 1 WHERE id = ?')->execute([$reset['id']]);
  $pdo->commit();
} catch (Exception $e) {
  $pdo->rollBack();
  error_log('Password reset failed: ' . $e->getMessage());
  json_error('Could not reset password — please try again.', 500);
}

json_out(['ok' => true]);
