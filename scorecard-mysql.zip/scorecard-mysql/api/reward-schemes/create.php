<?php
// POST { deptId, companyId, goalId, startDate, endDate, baseAmount } -> { scheme }.
// CEO/admin only. Replaces addRewardScheme().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$deptId = (string)($body['deptId'] ?? '');
$companyId = (string)($body['companyId'] ?? '');
$goalId = (string)($body['goalId'] ?? '');
$startDate = (string)($body['startDate'] ?? '');
$endDate = (string)($body['endDate'] ?? '');
$baseAmount = (float)($body['baseAmount'] ?? 0);
if ($deptId === '' || $companyId === '' || $goalId === '' || $startDate === '' || $endDate === '') {
  json_error('Missing required fields.', 400);
}

$id = new_uuid();
db()->prepare(
  'INSERT INTO reward_schemes (id, dept_id, company_id, goal_id, start_date, end_date, base_amount, active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)'
)->execute([$id, $deptId, $companyId, $goalId, $startDate, $endDate, $baseAmount]);

json_out(['scheme' => [
  'id' => $id, 'deptId' => $deptId, 'companyId' => $companyId, 'goalId' => $goalId,
  'startDate' => $startDate, 'endDate' => $endDate, 'baseAmount' => $baseAmount, 'active' => true,
  'enrolledEmployeeIds' => [], 'employeeOverrides' => new stdClass(),
  'futureBaseAmount' => null, 'futureEffectiveMonth' => null,
]]);
