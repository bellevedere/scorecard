<?php
// POST { schemeId, newBaseAmount, scope: "current"|"currentAndFuture" } -> { ok: true }.
// CEO/admin only. Replaces commitRewardSchemeEdit(). scope "current" applies now but
// records the old amount as future_base_amount/future_effective_month = next month (the
// "reverts next month" promise is carried over as-is from the original — note there's no
// rollover job that actually applies it yet, same gap the original had).

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php'; // current_iso_month() / next_iso_month()

require_method('POST');
require_ceo();

$body = read_json_body();
$schemeId = (string)($body['schemeId'] ?? '');
$newBaseAmount = (float)($body['newBaseAmount'] ?? 0);
$scope = ($body['scope'] ?? 'current') === 'currentAndFuture' ? 'currentAndFuture' : 'current';
if ($schemeId === '') json_error('Missing schemeId.', 400);

$stmt = db()->prepare('SELECT base_amount FROM reward_schemes WHERE id = ?');
$stmt->execute([$schemeId]);
$scheme = $stmt->fetch();
if (!$scheme) json_error('Reward scheme not found.', 404);

if ($scope === 'current') {
  $nxt = next_iso_month(current_iso_month());
  db()->prepare('UPDATE reward_schemes SET base_amount = ?, future_base_amount = ?, future_effective_month = ? WHERE id = ?')
    ->execute([$newBaseAmount, $scheme['base_amount'], $nxt, $schemeId]);
} else {
  db()->prepare('UPDATE reward_schemes SET base_amount = ?, future_base_amount = NULL, future_effective_month = NULL WHERE id = ?')
    ->execute([$newBaseAmount, $schemeId]);
}

json_out(['ok' => true]);
