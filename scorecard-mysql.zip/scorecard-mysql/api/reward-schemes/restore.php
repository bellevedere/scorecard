<?php
// POST { schemeId } -> { ok: true }. CEO/admin only. Replaces restoreRewardScheme().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$schemeId = (string)($body['schemeId'] ?? '');
if ($schemeId === '') json_error('Missing schemeId.', 400);

db()->prepare('UPDATE reward_schemes SET active = 1 WHERE id = ?')->execute([$schemeId]);
json_out(['ok' => true]);
