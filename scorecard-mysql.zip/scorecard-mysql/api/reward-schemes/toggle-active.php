<?php
// POST { schemeId } -> { active: bool }. CEO/admin only. Replaces toggleRewardActive().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$schemeId = (string)($body['schemeId'] ?? '');
if ($schemeId === '') json_error('Missing schemeId.', 400);

$stmt = db()->prepare('SELECT active FROM reward_schemes WHERE id = ?');
$stmt->execute([$schemeId]);
$row = $stmt->fetch();
if (!$row) json_error('Reward scheme not found.', 404);

$next = ((int)$row['active']) === 1 ? 0 : 1;
db()->prepare('UPDATE reward_schemes SET active = ? WHERE id = ?')->execute([$next, $schemeId]);
json_out(['active' => $next === 1]);
