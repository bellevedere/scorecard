<?php
// POST { name, email, role, deptId, companyId, password? } -> { employee }
// CEO/admin only. Replaces the "create-employee" Edge Function — there's no
// separate auth.users table here, so this is a single plain insert rather than the
// two-step (auth + employees) atomic operation Supabase needed.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$name = trim((string)($body['name'] ?? ''));
$email = trim(strtolower((string)($body['email'] ?? '')));
$role = ($body['role'] ?? 'staff') === 'ceo' ? 'ceo' : 'staff';
$deptId = $body['deptId'] ?? null;
$companyId = $body['companyId'] ?? null;
$password = (string)($body['password'] ?? '');

if ($name === '' || $email === '' || !$deptId) {
  json_error('Name, email, and department are required.', 400);
}
if ($password === '') {
  // No password typed in — generate a temp one so the account is still usable;
  // the admin can hand it over directly or reset it again via "Reset password".
  $password = bin2hex(random_bytes(5)); // 10-char temp password
}
if (strlen($password) < 6) json_error('Password must be at least 6 characters.', 400);

$stmt = db()->prepare('SELECT id FROM employees WHERE email = ?');
$stmt->execute([$email]);
if ($stmt->fetch()) json_error("An account with email $email already exists.", 409);

$id = new_uuid();
db()->prepare(
  'INSERT INTO employees (id, company_id, dept_id, name, email, password_hash, role, active)
   VALUES (?, ?, ?, ?, ?, ?, ?, 1)'
)->execute([$id, $companyId, $deptId, $name, $email, hash_password($password), $role]);

json_out([
  'employee' => [
    'id' => $id, 'name' => $name, 'email' => $email, 'role' => $role,
    'dept_id' => $deptId, 'company_id' => $companyId,
  ],
  'tempPassword' => $password, // shown to admin when they didn't type one themselves
]);
