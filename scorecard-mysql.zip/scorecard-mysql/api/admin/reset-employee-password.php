<?php
// POST { employeeId, newPassword } -> { ok: true }. CEO/admin only. Replaces the
// "admin-reset-password" Edge Function — lets an admin set a password directly for
// staff who have no real email (name@companyname.com accounts) and so can't use the
// self-service forgot-password flow.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? '');
$newPassword = (string)($body['newPassword'] ?? '');
if ($employeeId === '' || $newPassword === '') json_error('Missing employeeId or newPassword.', 400);
if (strlen($newPassword) < 6) json_error('Password must be at least 6 characters.', 400);

$stmt = db()->prepare('UPDATE employees SET password_hash = ? WHERE id = ?');
$stmt->execute([hash_password($newPassword), $employeeId]);
if ($stmt->rowCount() === 0) json_error('Employee not found.', 404);

json_out(['ok' => true]);
