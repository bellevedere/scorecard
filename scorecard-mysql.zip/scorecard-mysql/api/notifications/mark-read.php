<?php
// POST {} -> { ok: true }. Marks all of the signed-in employee's own unread notifications
// as read. Replaces markNotificationsRead() — always acts on the caller's own inbox only
// (the original called this with session.employeeId regardless of role, never another
// employee's), so there's no employeeId parameter to trust/misuse here.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
$me = require_session();

db()->prepare('UPDATE notifications SET `read` = 1 WHERE employee_id = ? AND `read` = 0')->execute([$me['id']]);
json_out(['ok' => true]);
