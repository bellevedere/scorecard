<?php
// GET -> { notifications: [...] }. Returns the signed-in employee's own notifications,
// newest first. Replaces the Supabase Realtime subscription — the frontend polls this
// endpoint every ~15-20s instead, since plain PHP/MySQL has no push-notification
// equivalent (see claude/scorecard-rls-status.md's deployment notes for why).

require_once __DIR__ . '/../../lib/auth.php';

require_method('GET');
$me = require_session();

$stmt = db()->prepare('SELECT * FROM notifications WHERE employee_id = ? ORDER BY created_at DESC');
$stmt->execute([$me['id']]);
$rows = $stmt->fetchAll();
foreach ($rows as &$r) {
  $r['important'] = ((int)$r['important']) === 1;
  $r['read'] = ((int)$r['read']) === 1;
}
unset($r);

json_out(['notifications' => $rows]);
