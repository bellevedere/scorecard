<?php
// POST { name, description } -> { company }. CEO/admin only. Replaces addCompany().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$name = trim((string)($body['name'] ?? ''));
$description = $body['description'] ?? null;
if ($name === '') json_error('Missing name.', 400);

$id = new_uuid();
db()->prepare('INSERT INTO companies (id, name, description, active) VALUES (?, ?, ?, 1)')
  ->execute([$id, $name, $description !== '' ? $description : null]);

json_out(['company' => ['id' => $id, 'name' => $name, 'description' => $description ?: '', 'active' => true]]);
