<?php
// POST { companyId } -> { ok: true }. CEO/admin only. Replaces restoreCompany() —
// deliberately leaves archived_reason/archived_proof_url/archived_at in place, kept as a
// permanent record of the last archival (the "letter of proof" is compliance
// documentation, not a transient UI state).

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$companyId = (string)($body['companyId'] ?? '');
if ($companyId === '') json_error('Missing companyId.', 400);

db()->prepare('UPDATE companies SET active = 1 WHERE id = ?')->execute([$companyId]);
json_out(['ok' => true]);
