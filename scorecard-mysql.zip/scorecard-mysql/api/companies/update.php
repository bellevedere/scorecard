<?php
// POST { companyId, patch: { name?, description? } } -> { ok: true }. CEO/admin only.
// Replaces updateCompany().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$companyId = (string)($body['companyId'] ?? '');
$patch = is_array($body['patch'] ?? null) ? $body['patch'] : [];
if ($companyId === '') json_error('Missing companyId.', 400);

$sets = [];
$params = [];
if (array_key_exists('name', $patch)) { $sets[] = 'name = ?'; $params[] = $patch['name']; }
if (array_key_exists('description', $patch)) { $sets[] = 'description = ?'; $params[] = $patch['description']; }
if (!$sets) json_out(['ok' => true]);

$params[] = $companyId;
db()->prepare('UPDATE companies SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
json_out(['ok' => true]);
