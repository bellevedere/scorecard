<?php
// POST multipart/form-data: companyId, reason, file field "proof" -> { ok: true,
// archivedProofUrl }. CEO/admin only. Replaces archiveCompany() — "deleting" a company is
// really archiving (never hard-deleted), gated behind a stated reason + an uploaded letter
// of proof, both kept permanently as a compliance record (restoring does NOT clear them).

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/storage.php';

require_method('POST');
require_ceo();

$companyId = (string)($_POST['companyId'] ?? '');
$reason = trim((string)($_POST['reason'] ?? ''));
if ($companyId === '') json_error('Missing companyId.', 400);
if ($reason === '') json_error('A reason is required to archive a company.', 400);
if (empty($_FILES['proof']['name'])) json_error('A letter of proof must be attached to archive a company.', 400);

$proofPath = store_company_file($_FILES['proof'], $companyId, 'letter');
$archivedAt = (new DateTime())->format('Y-m-d H:i:s');

db()->prepare(
  'UPDATE companies SET active = 0, archived_reason = ?, archived_proof_url = ?, archived_at = ? WHERE id = ?'
)->execute([$reason, $proofPath, $archivedAt, $companyId]);

json_out(['ok' => true, 'archivedReason' => $reason, 'archivedProofUrl' => $proofPath, 'archivedAt' => $archivedAt]);
