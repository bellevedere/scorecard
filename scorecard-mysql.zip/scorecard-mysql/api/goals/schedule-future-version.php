<?php
// POST { goalId, isoMonth, tasks: [...], assignedEmployeeIds: [...] } -> { ok: true }.
// CEO/admin only. Replaces scheduleFutureVersion() — schedules (or updates) a future
// month's version without touching anything live. Used for annual/recurring goals.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php';
require_once __DIR__ . '/../../lib/notifications.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$goalId = (string)($body['goalId'] ?? '');
$isoMonth = (string)($body['isoMonth'] ?? '');
$tasks = is_array($body['tasks'] ?? null) ? $body['tasks'] : [];
$assignedEmployeeIds = is_array($body['assignedEmployeeIds'] ?? null) ? $body['assignedEmployeeIds'] : [];
if ($goalId === '' || $isoMonth === '') json_error('Missing goalId or isoMonth.', 400);

$goal = find_goal($goalId);
if (!$goal) json_error('Goal not found.', 404);

$snapshot = array_map(fn($t) => [
  'text' => $t['text'], 'weight' => (float)$t['weight'],
  'requiresAttachment' => !empty($t['requiresAttachment']), 'requiresRemark' => !empty($t['requiresRemark']),
], $tasks);
upsert_future_version($goalId, $isoMonth, $snapshot, $assignedEmployeeIds);

foreach ($assignedEmployeeIds as $empId) {
  notify_employee($empId, "\"{$goal['name']}\" has scheduled changes for {$isoMonth}.", false);
}

json_out(['ok' => true]);
