<?php
// POST { goalId } -> { ok: true }. CEO/admin only. Replaces archiveGoal() — soft delete,
// the goal stays intact for historical reports but disappears from normal views.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$goalId = (string)($body['goalId'] ?? '');
if ($goalId === '') json_error('Missing goalId.', 400);

db()->prepare('UPDATE goals SET active = 0 WHERE id = ?')->execute([$goalId]);
json_out(['ok' => true]);
