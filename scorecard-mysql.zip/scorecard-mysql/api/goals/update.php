<?php
// POST { goalId, patch: { name?, description?, startDate?, endDate?, reviewCutoffDate?,
// reviewCutoffOffsetDays?, active? } } -> { ok: true }. CEO/admin only. Replaces
// updateGoal() — a plain field patch (only the listed fields are ever written).

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$FIELD_MAP = [
  'name' => 'name', 'description' => 'description', 'startDate' => 'start_date',
  'endDate' => 'end_date', 'reviewCutoffDate' => 'review_cutoff_date',
  'reviewCutoffOffsetDays' => 'review_cutoff_offset_days', 'active' => 'active',
];

$body = read_json_body();
$goalId = (string)($body['goalId'] ?? '');
$patch = is_array($body['patch'] ?? null) ? $body['patch'] : [];
if ($goalId === '') json_error('Missing goalId.', 400);

$sets = [];
$params = [];
foreach ($patch as $k => $v) {
  if (!isset($FIELD_MAP[$k])) continue;
  $sets[] = $FIELD_MAP[$k] . ' = ?';
  $params[] = $k === 'active' ? (!empty($v) ? 1 : 0) : $v;
}
if (!$sets) json_out(['ok' => true]); // nothing recognized to update — matches the frontend's no-op

$params[] = $goalId;
db()->prepare('UPDATE goals SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
json_out(['ok' => true]);
