<?php
// POST { deptId, name, description, startDate, endDate, reviewCutoffDate, tasks: [{text,
// weight, requiresAttachment, requiresRemark}], assignedEmployeeIds: [...], isAnnual?,
// isCore?, reviewCutoffOffsetDays? } -> { goal }. CEO/admin only. Replaces addGoal() —
// creates the goal row, its tasks, and its assignments together (in a transaction, so a
// failure partway through can't leave a goal with no tasks or a task with no goal).

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$deptId = (string)($body['deptId'] ?? '');
$name = trim((string)($body['name'] ?? ''));
$description = $body['description'] ?? null;
$startDate = (string)($body['startDate'] ?? '');
$endDate = (string)($body['endDate'] ?? '');
$reviewCutoffDate = $body['reviewCutoffDate'] ?? null;
$tasks = is_array($body['tasks'] ?? null) ? $body['tasks'] : [];
$assignedEmployeeIds = is_array($body['assignedEmployeeIds'] ?? null) ? $body['assignedEmployeeIds'] : [];
$isAnnual = !empty($body['isAnnual']);
$isCore = !empty($body['isCore']);
$reviewCutoffOffsetDays = $isAnnual ? ($body['reviewCutoffOffsetDays'] ?? 5) : null;

if ($deptId === '' || $name === '' || $startDate === '' || $endDate === '') {
  json_error('deptId, name, startDate, and endDate are required.', 400);
}

$pdo = db();
$pdo->beginTransaction();
try {
  $goalId = new_uuid();
  $pdo->prepare(
    'INSERT INTO goals (id, dept_id, name, description, is_team_goal, auto_assign_whole_dept, is_annual,
       active, start_date, end_date, review_cutoff_date, review_cutoff_offset_days, live_month)
     VALUES (?, ?, ?, ?, ?, 0, ?, 1, ?, ?, ?, ?, ?)'
  )->execute([
    $goalId, $deptId, $name, $description !== '' ? $description : null, $isCore ? 1 : 0, $isAnnual ? 1 : 0,
    $startDate, $endDate, $isAnnual ? null : $reviewCutoffDate, $reviewCutoffOffsetDays,
    $isAnnual ? current_iso_month() : null,
  ]);

  $insertedTasks = [];
  $sortOrder = 0;
  foreach ($tasks as $t) {
    $taskId = new_uuid();
    $pdo->prepare(
      'INSERT INTO goal_tasks (id, goal_id, text, weight, requires_attachment, requires_remark, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )->execute([$taskId, $goalId, $t['text'], $t['weight'], !empty($t['requiresAttachment']) ? 1 : 0, !empty($t['requiresRemark']) ? 1 : 0, $sortOrder]);
    $insertedTasks[] = ['id' => $taskId, 'text' => $t['text'], 'weight' => (float)$t['weight'],
      'requiresAttachment' => !empty($t['requiresAttachment']), 'requiresRemark' => !empty($t['requiresRemark'])];
    $sortOrder++;
  }

  foreach ($assignedEmployeeIds as $empId) {
    $pdo->prepare('INSERT IGNORE INTO goal_assignments (goal_id, employee_id) VALUES (?, ?)')->execute([$goalId, $empId]);
  }

  $pdo->commit();
} catch (Exception $e) {
  $pdo->rollBack();
  error_log('Failed to create goal: ' . $e->getMessage());
  json_error('Could not create the goal — please try again.', 500);
}

json_out(['goal' => [
  'id' => $goalId, 'deptId' => $deptId, 'name' => $name, 'description' => $description ?: '',
  'isTeamGoal' => $isCore, 'autoAssignWholeDept' => false, 'isAnnual' => $isAnnual, 'active' => true,
  'startDate' => $startDate, 'endDate' => $endDate,
  'reviewCutoffDate' => $isAnnual ? null : $reviewCutoffDate,
  'reviewCutoffOffsetDays' => $isAnnual ? $reviewCutoffOffsetDays : null,
  'tasks' => $insertedTasks, 'assignedEmployeeIds' => array_values($assignedEmployeeIds),
]]);
