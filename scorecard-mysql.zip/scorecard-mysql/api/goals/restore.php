<?php
// POST { goalId } -> { ok: true }. CEO/admin only. Replaces restoreGoal().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$goalId = (string)($body['goalId'] ?? '');
if ($goalId === '') json_error('Missing goalId.', 400);

db()->prepare('UPDATE goals SET active = 1 WHERE id = ?')->execute([$goalId]);
json_out(['ok' => true]);
