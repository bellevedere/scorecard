<?php
// POST { goalId, tasks: [...], assignedEmployeeIds: [...], scope: "current"|"currentAndFuture" }
// -> { tasks, assignedEmployeeIds, futureVersions }. CEO/admin only. Replaces
// commitCurrentMonthEdit() — applies an edit to a goal's LIVE current-month tasks/assignments.
// scope "current" additionally schedules a one-month-only revert back to the OLD definition
// starting next month (unless something is already scheduled from next month onward) —
// scope "currentAndFuture" just leaves the new definition live indefinitely. Nothing is ever
// wiped: approved records keep their frozen awarded_weight regardless of later task edits.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php';
require_once __DIR__ . '/../../lib/notifications.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$goalId = (string)($body['goalId'] ?? '');
$newTasks = is_array($body['tasks'] ?? null) ? $body['tasks'] : [];
$newAssignedEmployeeIds = is_array($body['assignedEmployeeIds'] ?? null) ? $body['assignedEmployeeIds'] : [];
$scope = ($body['scope'] ?? 'current') === 'currentAndFuture' ? 'currentAndFuture' : 'current';
if ($goalId === '') json_error('Missing goalId.', 400);

$goal = find_goal($goalId);
if (!$goal) json_error('Goal not found.', 404);

$oldTasks = goal_tasks_for($goalId);
$oldAssigned = goal_assigned_employee_ids($goalId);
$cur = current_iso_month();
$nxt = next_iso_month($cur);

$result = apply_live_goal_definition($goalId, $newTasks, $newAssignedEmployeeIds);

$futureVersions = [];
if ($scope === 'current') {
  $stmt = db()->prepare('SELECT effective_from_month FROM goal_future_versions WHERE goal_id = ? AND effective_from_month >= ?');
  $stmt->execute([$goalId, $nxt]);
  $alreadyScheduledAhead = (bool)$stmt->fetch();
  if (!$alreadyScheduledAhead) {
    $oldTaskSnapshot = array_map(fn($t) => [
      'text' => $t['text'], 'weight' => (float)$t['weight'],
      'requiresAttachment' => ((int)$t['requires_attachment']) === 1, 'requiresRemark' => ((int)$t['requires_remark']) === 1,
    ], $oldTasks);
    upsert_future_version($goalId, $nxt, $oldTaskSnapshot, $oldAssigned);
  }
}

$affected = array_unique(array_merge($oldAssigned, $result['assignedEmployeeIds']));
foreach ($affected as $empId) {
  notify_employee($empId, "\"{$goal['name']}\" was updated — check your goals for what changed. Anything already approved keeps its original points.", true);
}

json_out(['tasks' => $result['tasks'], 'assignedEmployeeIds' => $result['assignedEmployeeIds']]);
