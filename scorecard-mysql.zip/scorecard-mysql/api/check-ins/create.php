<?php
// POST multipart/form-data: employeeId, deptId, type ("in"|"out"), timestamp, lat, lng,
// elapsedSec, withinWindow ("1"/"0"), optional file field "photo" -> { checkIn }. Replaces
// addCheckin() — photo upload + reverse geocoding are both best-effort, same as the
// original: if either fails, the check-in itself still saves.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/storage.php';
require_once __DIR__ . '/../../lib/geocode.php';

require_method('POST');
$me = require_session();

$employeeId = (string)($_POST['employeeId'] ?? $me['id']);
if ($me['role'] !== 'ceo' && $employeeId !== $me['id']) json_error('You can only check in as yourself.', 403);

$deptId = $_POST['deptId'] ?? null;
$type = ($_POST['type'] ?? '') === 'out' ? 'out' : 'in';
$timestamp = (string)($_POST['timestamp'] ?? (new DateTime())->format('Y-m-d H:i:s'));
$lat = isset($_POST['lat']) && $_POST['lat'] !== '' ? (float)$_POST['lat'] : null;
$lng = isset($_POST['lng']) && $_POST['lng'] !== '' ? (float)$_POST['lng'] : null;
$elapsedSec = isset($_POST['elapsedSec']) && $_POST['elapsedSec'] !== '' ? (int)$_POST['elapsedSec'] : null;
$withinWindow = (string)($_POST['withinWindow'] ?? '0') === '1';

$photoPath = null;
if (!empty($_FILES['photo']['name'])) {
  try {
    $photoPath = store_uploaded_file($_FILES['photo'], (string)($me['company_id'] ?? ''), $employeeId, 'checkins');
  } catch (Throwable $e) {
    error_log('Check-in photo upload failed: ' . $e->getMessage());
    $photoPath = null; // best-effort — the check-in itself must still save
  }
}

$address = null;
if ($lat !== null && $lng !== null) {
  $address = reverse_geocode($lat, $lng);
}

$id = new_uuid();
db()->prepare(
  'INSERT INTO check_ins (id, employee_id, dept_id, type, timestamp, lat, lng, photo_url, elapsed_sec, within_window, address)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
)->execute([$id, $employeeId, $deptId, $type, $timestamp, $lat, $lng, $photoPath, $elapsedSec, $withinWindow ? 1 : 0, $address]);

json_out(['checkIn' => [
  'id' => $id, 'empId' => $employeeId, 'deptId' => $deptId, 'type' => $type, 'timestamp' => $timestamp,
  'lat' => $lat, 'lng' => $lng, 'photo' => $photoPath, 'elapsedSec' => $elapsedSec,
  'withinWindow' => $withinWindow, 'address' => $address,
]]);
