<?php
// POST { employeeId, goalId, taskId, awardedPoints? } -> { record }. CEO/admin only.
// Replaces setApproval() — the task's CURRENT weight is frozen into the record at this
// moment (awarded_weight), so a later change to the task's live weight never affects this
// already-approved record. Notifies the employee, same as the original.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php';
require_once __DIR__ . '/../../lib/goal_records.php';
require_once __DIR__ . '/../../lib/notifications.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? '');
$goalId = (string)($body['goalId'] ?? '');
$taskId = (string)($body['taskId'] ?? '');
$awardedPoints = array_key_exists('awardedPoints', $body) ? (float)$body['awardedPoints'] : null;
if ($employeeId === '' || $goalId === '' || $taskId === '') json_error('Missing employeeId, goalId, or taskId.', 400);

$stmt = db()->prepare('SELECT * FROM goal_tasks WHERE id = ?');
$stmt->execute([$taskId]);
$task = $stmt->fetch();

$cur = get_goal_record($employeeId, $goalId, $taskId);
$cur['approval'] = 'approved';
$cur['awarded_points'] = $awardedPoints ?? ($cur['awarded_points'] ?? 0);
$cur['awarded_weight'] = $task ? (float)$task['weight'] : $cur['awarded_weight'];
save_goal_record($cur);

if ($task) {
  $pts = $awardedPoints ?? $task['weight'];
  $msg = "\"{$task['text']}\" was approved for {$pts}/{$task['weight']} pts";
  if (!empty($cur['admin_remark'])) $msg .= " — {$cur['admin_remark']}";
  notify_employee($employeeId, $msg, false);
}

json_out(['record' => $cur]);
