<?php
// POST { employeeId, goalId, taskId, adminRemark } -> { record }. CEO/admin only. Replaces
// setAdminRemark() — admin's own note to the staff member, a separate field that never
// overwrites the staff's own remark.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goal_records.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? '');
$goalId = (string)($body['goalId'] ?? '');
$taskId = (string)($body['taskId'] ?? '');
$adminRemark = (string)($body['adminRemark'] ?? '');
if ($employeeId === '' || $goalId === '' || $taskId === '') json_error('Missing employeeId, goalId, or taskId.', 400);

$cur = get_goal_record($employeeId, $goalId, $taskId);
$cur['admin_remark'] = $adminRemark !== '' ? $adminRemark : null;
save_goal_record($cur);
json_out(['record' => $cur]);
