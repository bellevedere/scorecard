<?php
// POST { employeeId, goalId, taskId } -> { record }. Replaces toggleTask() — staff ticking/
// unticking their own task with no attachment/remark required. employeeId in the body is
// only checked against the signed-in user, never trusted on its own (see staff_guard_record).

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php';
require_once __DIR__ . '/../../lib/goal_records.php';

require_method('POST');
$me = require_session();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? $me['id']);
$goalId = (string)($body['goalId'] ?? '');
$taskId = (string)($body['taskId'] ?? '');
if ($goalId === '' || $taskId === '') json_error('Missing goalId or taskId.', 400);

$goal = find_goal($goalId);
if (!$goal) json_error('Goal not found.', 404);
if (is_goal_locked($goal)) json_error('This goal has ended and can no longer be updated.', 400);

$cur = get_goal_record($employeeId, $goalId, $taskId);
staff_guard_record($me, $employeeId, $cur);

if ($cur['done'] && $cur['approval'] === 'approved') {
  json_error('This task has already been approved — ask your admin to un-tick it if you need to change or resubmit anything.', 403);
}

if ($cur['done']) {
  $cur['done'] = false; $cur['approval'] = 'none'; $cur['awarded_points'] = null;
} else {
  $cur['done'] = true; $cur['approval'] = 'pending'; $cur['submitted_at'] = (new DateTime())->format('Y-m-d H:i:s');
}

save_goal_record($cur);
json_out(['record' => $cur]);
