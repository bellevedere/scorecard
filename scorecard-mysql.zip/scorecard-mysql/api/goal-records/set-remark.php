<?php
// POST { employeeId, goalId, taskId, remark } -> { record }. Replaces setRemark() — staff's
// own note on their submission, editable independently of ticking/submitting.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goal_records.php';

require_method('POST');
$me = require_session();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? $me['id']);
$goalId = (string)($body['goalId'] ?? '');
$taskId = (string)($body['taskId'] ?? '');
$remark = (string)($body['remark'] ?? '');
if ($goalId === '' || $taskId === '') json_error('Missing goalId or taskId.', 400);

$cur = get_goal_record($employeeId, $goalId, $taskId);
staff_guard_record($me, $employeeId, $cur);

$cur['remark'] = $remark !== '' ? $remark : null;
save_goal_record($cur);
json_out(['record' => $cur]);
