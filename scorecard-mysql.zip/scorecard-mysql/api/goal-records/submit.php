<?php
// POST multipart/form-data: employeeId, goalId, taskId, remark, noAttachmentReason ("1"/"0"),
// removeAttachment ("1" to clear an existing one), optional file field "attachment".
// -> { record }. Replaces submitTaskWithDetails() — staff submitting a task that requires a
// remark and/or an attachment. The upload itself (Supabase Storage in the old version) is
// handled right here via lib/storage.php rather than a separate call, same as the original
// did it all inside one function.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goals.php';
require_once __DIR__ . '/../../lib/goal_records.php';
require_once __DIR__ . '/../../lib/storage.php';

require_method('POST');
$me = require_session();

$employeeId = (string)($_POST['employeeId'] ?? $me['id']);
$goalId = (string)($_POST['goalId'] ?? '');
$taskId = (string)($_POST['taskId'] ?? '');
if ($goalId === '' || $taskId === '') json_error('Missing goalId or taskId.', 400);

$goal = find_goal($goalId);
if (!$goal) json_error('Goal not found.', 404);
if (is_goal_locked($goal)) json_error('This goal has ended and can no longer be updated.', 400);

$cur = get_goal_record($employeeId, $goalId, $taskId);
staff_guard_record($me, $employeeId, $cur);

$remark = isset($_POST['remark']) ? (string)$_POST['remark'] : $cur['remark'];
$noAttachmentReason = (string)($_POST['noAttachmentReason'] ?? '0') === '1';
$removeAttachment = (string)($_POST['removeAttachment'] ?? '0') === '1';

$attachmentPath = $cur['attachment_url'];
if (!empty($_FILES['attachment']['name'])) {
  $sub = $goalId . '-' . $taskId;
  $attachmentPath = store_uploaded_file($_FILES['attachment'], (string)($me['company_id'] ?? ''), $employeeId, $sub);
} elseif ($removeAttachment) {
  $attachmentPath = null;
}

$cur['done'] = true;
$cur['approval'] = 'pending';
$cur['submitted_at'] = (new DateTime())->format('Y-m-d H:i:s');
$cur['remark'] = $remark !== '' ? $remark : null;
$cur['attachment_url'] = $attachmentPath;
$cur['no_attachment_reason'] = $noAttachmentReason;

save_goal_record($cur);
json_out(['record' => $cur]);
