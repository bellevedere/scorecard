<?php
// POST multipart/form-data: employeeId, goalId, taskId, optional file field "attachment",
// or removeAttachment=1 to clear it. -> { record }. Replaces setAttachment() — attaching or
// clearing a file independently of a full submit.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goal_records.php';
require_once __DIR__ . '/../../lib/storage.php';

require_method('POST');
$me = require_session();

$employeeId = (string)($_POST['employeeId'] ?? $me['id']);
$goalId = (string)($_POST['goalId'] ?? '');
$taskId = (string)($_POST['taskId'] ?? '');
if ($goalId === '' || $taskId === '') json_error('Missing goalId or taskId.', 400);

$cur = get_goal_record($employeeId, $goalId, $taskId);
staff_guard_record($me, $employeeId, $cur);

$removeAttachment = (string)($_POST['removeAttachment'] ?? '0') === '1';

if (!empty($_FILES['attachment']['name'])) {
  $sub = $goalId . '-' . $taskId;
  $cur['attachment_url'] = store_uploaded_file($_FILES['attachment'], (string)($me['company_id'] ?? ''), $employeeId, $sub);
  $cur['no_attachment_reason'] = false;
} elseif ($removeAttachment) {
  $cur['attachment_url'] = null;
}

save_goal_record($cur);
json_out(['record' => $cur]);
