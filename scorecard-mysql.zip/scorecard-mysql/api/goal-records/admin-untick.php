<?php
// POST { employeeId, goalId, taskId } -> { record }. CEO/admin only. Replaces adminUntick() —
// this IS how rejection works: resets done/awardedPoints and sets approval to "rejected"
// (not "none", so staff get real feedback and reports don't show it as "not started").
// Notifies the employee, including the admin's remark if one's already been left.

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/goal_records.php';
require_once __DIR__ . '/../../lib/notifications.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? '');
$goalId = (string)($body['goalId'] ?? '');
$taskId = (string)($body['taskId'] ?? '');
if ($employeeId === '' || $goalId === '' || $taskId === '') json_error('Missing employeeId, goalId, or taskId.', 400);

$stmt = db()->prepare('SELECT text FROM goal_tasks WHERE id = ?');
$stmt->execute([$taskId]);
$task = $stmt->fetch();

$cur = get_goal_record($employeeId, $goalId, $taskId);
$cur['done'] = false;
$cur['approval'] = 'rejected';
$cur['awarded_points'] = null;
save_goal_record($cur);

if ($task) {
  $msg = "\"{$task['text']}\" was rejected by management";
  if (!empty($cur['admin_remark'])) $msg .= " — {$cur['admin_remark']}";
  notify_employee($employeeId, $msg, true);
}

json_out(['record' => $cur]);
