<?php
// POST { employeeId } -> { ok: true }. CEO/admin only. Replaces restoreEmployee().

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? '');
if ($employeeId === '') json_error('Missing employeeId.', 400);

db()->prepare('UPDATE employees SET active = 1 WHERE id = ?')->execute([$employeeId]);
json_out(['ok' => true]);
