<?php
// POST { employeeId, patch: { name?, role?, deptId? } } -> { ok: true }. CEO/admin only.
// Replaces updateEmployee() — a plain field patch, same 3 fields the original allowed
// (email/password changes go through their own dedicated flows, not this one).

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? '');
$patch = is_array($body['patch'] ?? null) ? $body['patch'] : [];
if ($employeeId === '') json_error('Missing employeeId.', 400);

$sets = [];
$params = [];
if (array_key_exists('name', $patch)) { $sets[] = 'name = ?'; $params[] = $patch['name']; }
if (array_key_exists('role', $patch)) { $sets[] = 'role = ?'; $params[] = $patch['role'] === 'ceo' ? 'ceo' : 'staff'; }
if (array_key_exists('deptId', $patch)) { $sets[] = 'dept_id = ?'; $params[] = $patch['deptId']; }
if (!$sets) json_out(['ok' => true]);

$params[] = $employeeId;
db()->prepare('UPDATE employees SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
json_out(['ok' => true]);
