<?php
// POST { employeeId } -> { ok: true }. CEO/admin only. Replaces archiveEmployee() — soft
// delete; also ends their active login sessions, same effect RLS-gated login used to have
// once `active = false` stopped current_employee() from finding them.

require_once __DIR__ . '/../../lib/auth.php';

require_method('POST');
require_ceo();

$body = read_json_body();
$employeeId = (string)($body['employeeId'] ?? '');
if ($employeeId === '') json_error('Missing employeeId.', 400);

db()->prepare('UPDATE employees SET active = 0 WHERE id = ?')->execute([$employeeId]);
db()->prepare('DELETE FROM sessions WHERE employee_id = ?')->execute([$employeeId]);
json_out(['ok' => true]);
