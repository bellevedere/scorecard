// Minimal service worker — its main job right now is just to exist, since a registered
// service worker is one of the requirements browsers check before offering "Add to Home Screen."
// It also caches the app shell so the icon/name/basic shell survive a flaky connection.
// This is intentionally simple — replace with a real caching/update strategy once the app
// has a backend and data that needs proper offline queuing.

const CACHE_NAME = "scorecard-shell-v1";
const SHELL_FILES = ["./", "./index.html", "./manifest.json", "./icon-192.png", "./icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // Network-first: always try to get the latest deployed file first (so a new index.html upload
  // shows up on next load, not "whenever the cache happens to expire"), and only fall back to the
  // cached copy if the network is unreachable — that's the actual offline-resilience this was for.
  // The old cache-first strategy here was the real cause of "I uploaded a new file but the site
  // still shows the old one, even after a hard refresh" — cache-first means it never even asks the
  // network once something's cached, no matter how many times the page is reloaded.
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
