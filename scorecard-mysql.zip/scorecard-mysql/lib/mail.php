<?php
// Sends mail via PHP's built-in mail() (cPanel's local mail server) — works without
// any extra setup as long as MAIL_FROM_ADDRESS in config.php is a real mailbox on
// this cPanel account. If reset-code emails end up in spam a lot, the fix is to
// create that mailbox properly under Email Accounts (not just type an address here)
// and make sure SPF/DKIM are enabled for the domain (cPanel does this automatically
// for most setups under Email → Authentication).

require_once __DIR__ . '/../config.php';

function send_mail(string $to, string $subject, string $bodyText): bool {
  $headers = [];
  $headers[] = 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM_ADDRESS . '>';
  $headers[] = 'Content-Type: text/plain; charset=utf-8';
  $headers[] = 'X-Mailer: PHP/' . phpversion();

  $ok = @mail($to, $subject, $bodyText, implode("\r\n", $headers));
  if (!$ok) {
    error_log("send_mail failed: to=$to subject=$subject");
  }
  return $ok;
}
