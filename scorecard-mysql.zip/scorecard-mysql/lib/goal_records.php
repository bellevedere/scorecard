<?php
// Shared logic for reading/writing goal_records — the table that replaces Supabase RLS's
// most important rule: once a record's approval = 'approved', the owning staff member can
// never touch it again (frozen-approval philosophy, see claude/scorecard-rls-status.md).
// Every endpoint under api/goal-records/ that a STAFF member can call must run its write
// through staff_guard_record() below so that rule is enforced here in PHP exactly the way
// Postgres RLS used to enforce it in the old Supabase backend.

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/response.php';

function default_goal_record(string $employeeId, string $goalId, string $taskId): array {
  return [
    'employee_id' => $employeeId, 'goal_id' => $goalId, 'task_id' => $taskId,
    'done' => false, 'approval' => 'none', 'remark' => null, 'admin_remark' => null,
    'submitted_at' => null, 'awarded_points' => null, 'awarded_weight' => null,
    'attachment_url' => null, 'no_attachment_reason' => false,
  ];
}

// Fetches one goal_records row, or the same shape as a fresh/untouched record if none
// exists yet — mirrors the frontend's own getRecord()/defaultRecord() fallback.
function get_goal_record(string $employeeId, string $goalId, string $taskId): array {
  $stmt = db()->prepare('SELECT * FROM goal_records WHERE employee_id = ? AND goal_id = ? AND task_id = ?');
  $stmt->execute([$employeeId, $goalId, $taskId]);
  $row = $stmt->fetch();
  if (!$row) return default_goal_record($employeeId, $goalId, $taskId);
  $row['done'] = ((int)$row['done']) === 1;
  $row['no_attachment_reason'] = ((int)$row['no_attachment_reason']) === 1;
  if ($row['awarded_points'] !== null) $row['awarded_points'] = $row['awarded_points'] + 0;
  if ($row['awarded_weight'] !== null) $row['awarded_weight'] = $row['awarded_weight'] + 0;
  return $row;
}

// Whole-row upsert — same approach persistRecord() used against Supabase (simplest way to
// stay correct given how many different fields the various mutators each touch).
function save_goal_record(array $record): void {
  db()->prepare(
    'INSERT INTO goal_records
       (employee_id, goal_id, task_id, done, approval, remark, admin_remark, submitted_at,
        awarded_points, awarded_weight, attachment_url, no_attachment_reason)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       done = VALUES(done), approval = VALUES(approval), remark = VALUES(remark),
       admin_remark = VALUES(admin_remark), submitted_at = VALUES(submitted_at),
       awarded_points = VALUES(awarded_points), awarded_weight = VALUES(awarded_weight),
       attachment_url = VALUES(attachment_url), no_attachment_reason = VALUES(no_attachment_reason)'
  )->execute([
    $record['employee_id'], $record['goal_id'], $record['task_id'],
    $record['done'] ? 1 : 0, $record['approval'], $record['remark'], $record['admin_remark'],
    $record['submitted_at'], $record['awarded_points'], $record['awarded_weight'],
    $record['attachment_url'], $record['no_attachment_reason'] ? 1 : 0,
  ]);
}

// Mirrors isGoalLocked(goal) from index.html: non-annual goals lock the instant their
// end_date passes; annual goals are never "locked" this way (they use the separate
// per-month review-cutoff check instead, done by the caller when it matters).
function is_goal_locked(array $goal): bool {
  if (((int)$goal['is_annual']) === 1) return false;
  $endOfDay = new DateTime($goal['end_date'] . ' 23:59:59');
  return new DateTime() > $endOfDay;
}

// The core staff-side permission gate: a signed-in staff member may only ever write their
// OWN record, and never one that is currently approved — matching Postgres RLS's
// `employee_id = auth.uid() AND approval <> 'approved'` policy on both INSERT and UPDATE.
// Stops the request with a 403 (never a silent no-op) if either rule is violated, so a
// blocked write is never mistaken for a successful one, unlike the old frontend-only check.
function staff_guard_record(array $me, string $employeeId, array $currentRecord): void {
  if ($me['role'] !== 'ceo' && $employeeId !== $me['id']) {
    json_error('You can only update your own tasks.', 403);
  }
  if ($me['role'] !== 'ceo' && $currentRecord['approval'] === 'approved') {
    json_error('This task has already been approved — ask your admin to un-tick it if you need to change or resubmit anything.', 403);
  }
}
