<?php
// Replaces addNotification(empId, message, important) — inserts a row the frontend
// will later pick up via polling (api/notifications/list.php, not built yet).

require_once __DIR__ . '/db.php';

function notify_employee(string $employeeId, string $message, bool $important = false): void {
  db()->prepare(
    'INSERT INTO notifications (id, employee_id, message, important, `read`) VALUES (?, ?, ?, ?, 0)'
  )->execute([new_uuid(), $employeeId, $message, $important ? 1 : 0]);
}
