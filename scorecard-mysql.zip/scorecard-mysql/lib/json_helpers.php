<?php
// Small helpers for shaping raw PDO rows back into the exact JSON shape the frontend
// already expects (the same shape Supabase/PostgREST used to hand it) — mainly this
// means casting MySQL's TINYINT(1) ("0"/"1" strings via PDO) into real JSON
// true/false, since index.html's own mapping code does strict checks like
// `c.active !== false` that only work against a real boolean.

// Casts the given column names on every row of $rows to real PHP booleans in place.
function cast_bools(array $rows, array $boolFields): array {
  foreach ($rows as &$row) {
    foreach ($boolFields as $f) {
      if (array_key_exists($f, $row)) $row[$f] = ((int)$row[$f]) === 1;
    }
  }
  unset($row);
  return $rows;
}

// Casts the given column names on every row of $rows from a JSON text column into a
// real decoded value (array/object), so it isn't double-encoded when we json_encode
// the whole response.
function decode_json_fields(array $rows, array $jsonFields): array {
  foreach ($rows as &$row) {
    foreach ($jsonFields as $f) {
      if (array_key_exists($f, $row) && $row[$f] !== null) {
        $decoded = json_decode($row[$f], true);
        $row[$f] = $decoded === null && json_last_error() !== JSON_ERROR_NONE ? [] : $decoded;
      }
    }
  }
  unset($row);
  return $rows;
}

// Casts the given numeric column names (DECIMAL columns come back as strings via PDO)
// to real PHP int/float so the frontend's Number(...)-free arithmetic still works.
function cast_numbers(array $rows, array $numberFields): array {
  foreach ($rows as &$row) {
    foreach ($numberFields as $f) {
      if (array_key_exists($f, $row) && $row[$f] !== null) $row[$f] = $row[$f] + 0;
    }
  }
  unset($row);
  return $rows;
}
