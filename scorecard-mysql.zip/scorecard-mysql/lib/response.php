<?php
// Small helpers every endpoint uses so error handling/JSON shape stays consistent.

header('Content-Type: application/json; charset=utf-8');
// Frontend and API live on the same subdomain after migration, so no CORS headers
// are needed here — if that ever changes, add Access-Control-Allow-Origin then.

function json_out($data, int $status = 200): void {
  http_response_code($status);
  echo json_encode($data);
  exit;
}

function json_error(string $message, int $status = 400): void {
  json_out(['error' => $message], $status);
}

// Reads and decodes the request's JSON body (every endpoint here expects
// Content-Type: application/json, matching how the frontend will call these).
function read_json_body(): array {
  $raw = file_get_contents('php://input');
  $data = json_decode($raw ?: '[]', true);
  if (!is_array($data)) json_error('Invalid JSON body.', 400);
  return $data;
}

function require_method(string $method): void {
  if (($_SERVER['REQUEST_METHOD'] ?? '') !== $method) {
    json_error('Method not allowed.', 405);
  }
}
