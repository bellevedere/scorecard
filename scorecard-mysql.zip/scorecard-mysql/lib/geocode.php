<?php
// Reverse geocoding — replaces the Supabase "reverse-geocode" Edge Function (see
// /home/claude/scratch/edge-function/reverse-geocode.ts, ported line-for-line). Tries
// OpenCage first (precise, needs OPENCAGE_API_KEY in config.php), falls back to Nominatim
// (free, no key, coarser) if no key is set or OpenCage returns nothing — so check-ins never
// break even with an empty key.

require_once __DIR__ . '/../config.php';

function http_get_json(string $url, array $headers = []): ?array {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 8,
    CURLOPT_HTTPHEADER => $headers,
  ]);
  $raw = curl_exec($ch);
  $ok = $raw !== false && curl_getinfo($ch, CURLINFO_HTTP_CODE) < 400;
  curl_close($ch);
  if (!$ok || !$raw) return null;
  $data = json_decode($raw, true);
  return is_array($data) ? $data : null;
}

function try_opencage(float $lat, float $lng, string $apiKey): ?string {
  $url = 'https://api.opencagedata.com/geocode/v1/json?q=' . urlencode("$lat+$lng")
    . '&key=' . urlencode($apiKey) . '&no_annotations=1&language=en';
  $data = http_get_json($url);
  $result = $data['results'][0] ?? null;
  $formatted = $result['formatted'] ?? null;
  if (!$formatted) return null;

  // OpenCage's "formatted" is a street address — it doesn't include the venue/business name
  // even when the point sits right on one. Prefix it on from "components" when present.
  $c = $result['components'] ?? [];
  $venueName = $c['shop'] ?? $c['amenity'] ?? $c['attraction'] ?? $c['building'] ?? $c['office'] ?? $c['tourism'] ?? $c['leisure'] ?? null;
  if ($venueName && stripos($formatted, (string)$venueName) !== 0) {
    return "$venueName, $formatted";
  }
  return $formatted;
}

function try_nominatim(float $lat, float $lng): ?string {
  $url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$lat&lon=$lng&addressdetails=1";
  $data = http_get_json($url, [
    'User-Agent: Scorecard-KPI-App/1.0 (internal staff check-in tool)',
    'Accept-Language: en',
  ]);
  return $data['display_name'] ?? null;
}

// Best-effort — returns null (never throws) if both providers fail, same as the original
// Edge Function, so a check-in always saves even without an address.
function reverse_geocode(float $lat, float $lng): ?string {
  try {
    $apiKey = defined('OPENCAGE_API_KEY') ? OPENCAGE_API_KEY : '';
    if ($apiKey) {
      $address = try_opencage($lat, $lng, $apiKey);
      if ($address) return $address;
    }
    return try_nominatim($lat, $lng);
  } catch (Exception $e) {
    error_log('Reverse geocoding failed: ' . $e->getMessage());
    return null;
  }
}
