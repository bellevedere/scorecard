<?php
// Session + password helpers. Replaces Supabase Auth entirely: login creates a row
// in `sessions` and hands the browser a random token as an HttpOnly cookie; every
// protected endpoint calls require_session() (or require_role()) to check it.

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/../config.php';

const SESSION_COOKIE = 'scorecard_session';

function create_session(string $employeeId): string {
  $token = bin2hex(random_bytes(32));
  $expiresAt = (new DateTime())->modify('+' . SESSION_LIFETIME_DAYS . ' days')->format('Y-m-d H:i:s');
  $stmt = db()->prepare('INSERT INTO sessions (token, employee_id, expires_at) VALUES (?, ?, ?)');
  $stmt->execute([$token, $employeeId, $expiresAt]);

  setcookie(SESSION_COOKIE, $token, [
    'expires' => time() + SESSION_LIFETIME_DAYS * 86400,
    'path' => '/',
    'secure' => true,     // HTTPS only — fine once AutoSSL has issued a cert for the subdomain
    'httponly' => true,   // never readable from JS, so an XSS bug can't steal the session
    'samesite' => 'Lax',
  ]);
  return $token;
}

function destroy_session(): void {
  $token = $_COOKIE[SESSION_COOKIE] ?? null;
  if ($token) {
    db()->prepare('DELETE FROM sessions WHERE token = ?')->execute([$token]);
  }
  setcookie(SESSION_COOKIE, '', ['expires' => time() - 3600, 'path' => '/']);
}

// Returns the logged-in employee's row (as an assoc array, snake_case straight from
// MySQL) or null if there's no valid session. Doesn't stop the request — use
// require_session() below when the endpoint actually needs someone logged in.
function current_employee(): ?array {
  $token = $_COOKIE[SESSION_COOKIE] ?? null;
  if (!$token) return null;

  $stmt = db()->prepare(
    'SELECT e.* FROM sessions s JOIN employees e ON e.id = s.employee_id
     WHERE s.token = ? AND s.expires_at > NOW() AND e.active = 1'
  );
  $stmt->execute([$token]);
  $emp = $stmt->fetch();
  return $emp ?: null;
}

// Call at the top of any endpoint that requires someone to be logged in.
function require_session(): array {
  $emp = current_employee();
  if (!$emp) json_error('Not signed in.', 401);
  return $emp;
}

// Call at the top of any endpoint only the CEO/admin role may use.
function require_ceo(): array {
  $emp = require_session();
  if ($emp['role'] !== 'ceo') json_error('Admins only.', 403);
  return $emp;
}

// Shapes a DB employee row into the { role, employeeId, name, email, deptId, companyId }
// object index.html's onLogin()/session state expects (mirrors the old
// signInAndEnter()'s onLogin(...) call exactly).
function session_payload(array $emp): array {
  return [
    'role' => $emp['role'],
    'employeeId' => $emp['id'],
    'name' => $emp['name'],
    'email' => $emp['email'],
    'deptId' => $emp['dept_id'],
    'companyId' => $emp['company_id'],
  ];
}

function hash_password(string $plain): string {
  return password_hash($plain, PASSWORD_BCRYPT);
}

function verify_password(string $plain, string $hash): bool {
  return password_verify($plain, $hash);
}
