<?php
// Shared helpers for goals / goal_tasks / goal_assignments, used by every endpoint
// under api/goals/, api/goal-tasks/, api/goal-assignments/.

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/response.php';

function find_goal(string $goalId): ?array {
  $stmt = db()->prepare('SELECT * FROM goals WHERE id = ?');
  $stmt->execute([$goalId]);
  $row = $stmt->fetch();
  return $row ?: null;
}

function goal_tasks_for(string $goalId): array {
  $stmt = db()->prepare('SELECT * FROM goal_tasks WHERE goal_id = ? ORDER BY sort_order ASC');
  $stmt->execute([$goalId]);
  return $stmt->fetchAll();
}

function goal_assigned_employee_ids(string $goalId): array {
  $stmt = db()->prepare('SELECT employee_id FROM goal_assignments WHERE goal_id = ?');
  $stmt->execute([$goalId]);
  return array_column($stmt->fetchAll(), 'employee_id');
}

// Diff-applies a new task list + assignment list onto a goal's LIVE goal_tasks/goal_assignments,
// same as applyLiveGoalDefinition() in index.html: only genuinely new tasks get inserted, only
// genuinely removed ones get deleted, matched ones get updated in place so goal_records rows
// tied to them stay linked. $newTasks entries: ['id' => existing-task-id-or-null, 'text', 'weight',
// 'requiresAttachment', 'requiresRemark']. Returns the final task list (with real ids filled in).
function apply_live_goal_definition(string $goalId, array $newTasks, array $newAssignedEmployeeIds): array {
  $pdo = db();
  $oldTasks = goal_tasks_for($goalId);
  $oldTaskIds = array_column($oldTasks, 'id');
  $newTaskIds = array_filter(array_column($newTasks, 'id'));

  $toDelete = array_diff($oldTaskIds, $newTaskIds);
  if ($toDelete) {
    $placeholders = implode(',', array_fill(0, count($toDelete), '?'));
    $pdo->prepare("DELETE FROM goal_tasks WHERE id IN ($placeholders)")->execute(array_values($toDelete));
  }

  $sortOrder = 0;
  $finalTasks = [];
  foreach ($newTasks as $t) {
    $isExisting = !empty($t['id']) && in_array($t['id'], $oldTaskIds, true);
    if ($isExisting) {
      $pdo->prepare(
        'UPDATE goal_tasks SET text = ?, weight = ?, requires_attachment = ?, requires_remark = ?, sort_order = ? WHERE id = ?'
      )->execute([
        $t['text'], $t['weight'], !empty($t['requiresAttachment']) ? 1 : 0, !empty($t['requiresRemark']) ? 1 : 0,
        $sortOrder, $t['id'],
      ]);
      $finalTasks[] = ['id' => $t['id'], 'text' => $t['text'], 'weight' => $t['weight'],
        'requiresAttachment' => !empty($t['requiresAttachment']), 'requiresRemark' => !empty($t['requiresRemark'])];
    } else {
      $id = new_uuid();
      $pdo->prepare(
        'INSERT INTO goal_tasks (id, goal_id, text, weight, requires_attachment, requires_remark, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)'
      )->execute([$id, $goalId, $t['text'], $t['weight'], !empty($t['requiresAttachment']) ? 1 : 0, !empty($t['requiresRemark']) ? 1 : 0, $sortOrder]);
      $finalTasks[] = ['id' => $id, 'text' => $t['text'], 'weight' => $t['weight'],
        'requiresAttachment' => !empty($t['requiresAttachment']), 'requiresRemark' => !empty($t['requiresRemark'])];
    }
    $sortOrder++;
  }

  $oldAssigned = goal_assigned_employee_ids($goalId);
  $toUnassign = array_diff($oldAssigned, $newAssignedEmployeeIds);
  $toAssign = array_diff($newAssignedEmployeeIds, $oldAssigned);
  if ($toUnassign) {
    $placeholders = implode(',', array_fill(0, count($toUnassign), '?'));
    $pdo->prepare("DELETE FROM goal_assignments WHERE goal_id = ? AND employee_id IN ($placeholders)")
      ->execute(array_merge([$goalId], array_values($toUnassign)));
  }
  foreach ($toAssign as $empId) {
    $pdo->prepare('INSERT IGNORE INTO goal_assignments (goal_id, employee_id) VALUES (?, ?)')->execute([$goalId, $empId]);
  }

  return ['tasks' => $finalTasks, 'assignedEmployeeIds' => $newAssignedEmployeeIds];
}

// Upserts one goal_future_versions row (used by both the "schedule a one-month revert" step
// inside commit-current-month-edit, and the standalone schedule-future-version endpoint).
function upsert_future_version(string $goalId, string $isoMonth, array $tasksSnapshot, array $assignedSnapshot): void {
  db()->prepare(
    'INSERT INTO goal_future_versions (goal_id, effective_from_month, tasks_snapshot, assigned_snapshot)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE tasks_snapshot = VALUES(tasks_snapshot), assigned_snapshot = VALUES(assigned_snapshot)'
  )->execute([$goalId, $isoMonth, json_encode(array_values($tasksSnapshot)), json_encode(array_values($assignedSnapshot))]);
}

function current_iso_month(): string {
  return (new DateTime())->format('Y-m');
}

function next_iso_month(string $isoMonth): string {
  return (new DateTime($isoMonth . '-01'))->modify('+1 month')->format('Y-m');
}
