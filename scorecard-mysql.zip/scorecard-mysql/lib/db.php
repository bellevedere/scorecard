<?php
// One shared PDO connection, reused by every endpoint that includes this file.

require_once __DIR__ . '/../config.php';

function db(): PDO {
  static $pdo = null;
  if ($pdo === null) {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    try {
      $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
      ]);
    } catch (PDOException $e) {
      error_log('DB connection failed: ' . $e->getMessage());
      http_response_code(500);
      header('Content-Type: application/json');
      echo json_encode(['error' => 'Database connection failed. Check config.php credentials.']);
      exit;
    }
  }
  return $pdo;
}

// Generates a UUID v4, the same shape Supabase used (xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx),
// so new rows created here look identical to ones migrated over from Supabase.
function new_uuid(): string {
  $data = random_bytes(16);
  $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // version 4
  $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // variant
  return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}
