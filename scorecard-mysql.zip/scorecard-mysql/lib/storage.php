<?php
// Replaces Supabase Storage. Files are saved under STORAGE_ROOT (outside the web root —
// see config.php) in the same folder convention the old buckets used:
//   {company_id}/{employee_id}/{sub}/{timestamp}-{safe-filename}
// and only that relative path is ever stored in the database — never a public URL — so a
// file can only be reached through api/files/download.php, which checks permission first.

require_once __DIR__ . '/response.php';
require_once __DIR__ . '/../config.php';

// Moves an uploaded file (from $_FILES[...]) into STORAGE_ROOT and returns the relative
// path to store in the database (e.g. in goal_records.attachment_url). $sub is a short
// folder segment identifying what the file belongs to (e.g. "{goalId}-{taskId}").
function store_uploaded_file(array $file, string $companyId, string $employeeId, string $sub): string {
  if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    json_error('File upload failed (code ' . ($file['error'] ?? 'unknown') . ').', 400);
  }
  $maxBytes = 15 * 1024 * 1024; // 15MB — generous for a phone screenshot/photo/PDF
  if (($file['size'] ?? 0) > $maxBytes) json_error('File is too large (max 15MB).', 400);

  $safeCompany = $companyId !== '' ? $companyId : 'unassigned';
  $safeName = preg_replace('/[^a-zA-Z0-9.\-]+/', '-', $file['name']);
  $relDir = "$safeCompany/$employeeId/$sub";
  $relPath = $relDir . '/' . time() . '-' . $safeName;

  $absDir = rtrim(STORAGE_ROOT, '/') . '/' . $relDir;
  if (!is_dir($absDir) && !mkdir($absDir, 0750, true) && !is_dir($absDir)) {
    json_error('Could not create storage folder — check STORAGE_ROOT permissions.', 500);
  }
  $absPath = rtrim(STORAGE_ROOT, '/') . '/' . $relPath;
  if (!move_uploaded_file($file['tmp_name'], $absPath)) {
    json_error('Could not save the uploaded file.', 500);
  }
  return $relPath;
}

// Same idea as store_uploaded_file(), but for files that belong to a COMPANY rather than
// one employee (the "letters-of-proof" bucket's old convention: {company_id}/{timestamp}-
// {filename}, no employee segment) — e.g. the letter of proof attached when archiving a
// company. Only CEO/admin ever uploads or views these (see api/companies/archive.php and
// the ownerless-path handling in storage_owner_employee_id() below).
function store_company_file(array $file, string $companyId, string $sub): string {
  if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    json_error('File upload failed (code ' . ($file['error'] ?? 'unknown') . ').', 400);
  }
  $maxBytes = 15 * 1024 * 1024;
  if (($file['size'] ?? 0) > $maxBytes) json_error('File is too large (max 15MB).', 400);

  $safeName = preg_replace('/[^a-zA-Z0-9.\-]+/', '-', $file['name']);
  $relDir = "$companyId/$sub";
  $relPath = $relDir . '/' . time() . '-' . $safeName;

  $absDir = rtrim(STORAGE_ROOT, '/') . '/' . $relDir;
  if (!is_dir($absDir) && !mkdir($absDir, 0750, true) && !is_dir($absDir)) {
    json_error('Could not create storage folder — check STORAGE_ROOT permissions.', 500);
  }
  $absPath = rtrim(STORAGE_ROOT, '/') . '/' . $relPath;
  if (!move_uploaded_file($file['tmp_name'], $absPath)) {
    json_error('Could not save the uploaded file.', 500);
  }
  return $relPath;
}

// Resolves a stored relative path to an absolute one inside STORAGE_ROOT, refusing
// anything that tries to escape it (defence in depth against a tampered path).
function storage_abs_path(string $relPath): ?string {
  $root = realpath(STORAGE_ROOT);
  $abs = realpath(rtrim(STORAGE_ROOT, '/') . '/' . ltrim($relPath, '/'));
  if ($root === false || $abs === false) return null;
  if (strpos($abs, $root) !== 0) return null; // path traversal guard
  return $abs;
}

// A stored path is "{companyId}/{employeeId}/...": pulls the employeeId segment back out
// so download.php can check "is this your own file" without a database round-trip.
function storage_owner_employee_id(string $relPath): ?string {
  $parts = explode('/', ltrim($relPath, '/'));
  return $parts[1] ?? null;
}
